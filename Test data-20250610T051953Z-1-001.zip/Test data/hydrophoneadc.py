from machine import Pin, ADC  # import functions
from time import sleep

adc = ADC(0) # assign ADC
#p13 = Pin(13, Pin.OUT) # assign pin that will power circuit

datafile = open("ADC.txt", "a") # create a data file

for i in range(100): # start loop
    #p13.value(1) # turn on power to circuit
    print(adc.read()/1024) # read  voltage from ADC (voltage across R2)
    datafile.write(str(adc.read()/1024) + "\n") # write voltage value to data file
    sleep(1) # pause for 1 sec
    #p13.value(0) # turn off power to circuit
    print(adc.read()/1024) # read  voltage from ADC (voltage across R2)
    datafile.write(str(adc.read()/1024) + "\n") # write voltage value to data file
    sleep(1)

    
datafile.close() # close the data file